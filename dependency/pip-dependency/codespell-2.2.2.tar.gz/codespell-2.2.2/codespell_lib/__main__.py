from ._codespell import _script_main

if __name__ == '__main__':
    _script_main()
