"""This is here because mypy doesn't understand PEP 420."""
from __future__ import annotations
