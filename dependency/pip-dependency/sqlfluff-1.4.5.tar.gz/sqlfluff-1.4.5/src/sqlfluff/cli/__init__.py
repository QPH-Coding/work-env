"""init py for cli."""


EXIT_SUCCESS = 0
EXIT_FAIL = 1
EXIT_ERROR = 2
