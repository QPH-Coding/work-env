"""Reflow utilities for sqlfluff rules."""

from sqlfluff.utils.reflow.sequence import ReflowSequence

__all__ = ("ReflowSequence",)
