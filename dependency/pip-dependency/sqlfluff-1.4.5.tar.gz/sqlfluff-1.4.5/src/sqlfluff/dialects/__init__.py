"""Dialects, segregated to make imports manageable.

NOTE: dialects should not be imported directly from this
module, but should be accessed instead using the selector
methods in `sqlfluff.core.dialects`.
"""
