#!/usr/bin/env python
"""The script for setting up sqlfluff."""
from setuptools import setup

setup()
