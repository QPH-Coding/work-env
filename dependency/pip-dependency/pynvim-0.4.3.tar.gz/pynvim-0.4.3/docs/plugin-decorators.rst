Plugin Decorators
=================

.. module:: pynvim.plugin

Plugin decorators.

Plugin
------

.. autofunction:: plugin

Command
-------

.. autofunction:: command

Autocmd
-------

.. autofunction:: autocmd

Function
--------

.. autofunction:: function
