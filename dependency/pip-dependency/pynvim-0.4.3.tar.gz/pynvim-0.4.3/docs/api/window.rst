Window Class
============

.. autoclass:: pynvim.api.Window
   :members:
