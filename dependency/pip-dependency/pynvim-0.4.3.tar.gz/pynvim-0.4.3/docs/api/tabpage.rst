Tabpage Class
=============

.. autoclass:: pynvim.api.Tabpage
   :members:
